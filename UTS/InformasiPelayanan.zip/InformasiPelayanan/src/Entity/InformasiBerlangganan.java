/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author LENOVO
 */
public class InformasiBerlangganan {
    public static String namaPaket[] = {"Biasa", "Lumayan", "Istimuewahh"};
    public static int hargaPaket[] = {10000,20000, 30000};
    public int maxDaftar[] = {5, 5, 5};
}
